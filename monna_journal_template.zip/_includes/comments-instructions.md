Utterances instructions:
1. Create a GitHub repository called `YOUR_GITHUB_USERNAME.github.io`.
2. Install the Utterances app on that repo or grant access.
3. Edit `_includes/footer.html` and replace `YOUR_GITHUB_USERNAME/REPO` with `YOUR_GITHUB_USERNAME/YOUR_REPO_NAME`.
4. Commits will map page paths to GitHub issues for comments.
