Replace these files with your photos (max 4-5 per post). Name images clearly, e.g. 2025-11-10-morning-walk.jpg
